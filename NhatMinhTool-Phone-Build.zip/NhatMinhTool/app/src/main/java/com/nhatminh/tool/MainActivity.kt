package com.nhatminh.tool

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(Color.rgb(18, 20, 30))
        }
        root.addView(TextView(this).apply {
            text = "NHATMINH TOOL\n\nBảng công cụ nổi hỗ trợ thao tác nhanh trên Android."
            textSize = 22f
            setTextColor(Color.WHITE)
        })
        root.addView(Button(this).apply {
            text = "CẤP QUYỀN HIỂN THỊ TRÊN ỨNG DỤNG KHÁC"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(Button(this).apply {
            text = "BẬT NÚT CÔNG CỤ NỔI"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, FloatingService::class.java))
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        })
        root.addView(Button(this).apply {
            text = "MỞ AZOTA"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://azota.vn")))
            }
        })
        root.addView(TextView(this).apply {
            text = "\nCông cụ chỉ tạo lối tắt và bảng tiện ích. Không đọc đề, chọn đáp án, tự nộp bài hoặc can thiệp hệ thống Azota."
            textSize = 14f
            setTextColor(Color.LTGRAY)
        })
        setContentView(root)
    }
}
