package com.nhatminh.tool

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private val channelId = "nhatminh_tool_overlay"

    override fun onCreate() {
        super.onCreate()
        createNotification()
        startForeground(7, Notification.Builder(this, channelId)
            .setContentTitle("NHATMINH TOOL đang hoạt động")
            .setContentText("Nhấn nút nổi để mở bảng tiện ích")
            .setSmallIcon(android.R.drawable.ic_menu_view).build())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "NHATMINH TOOL", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun params(): WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "NM"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(20, 115, 230)); setStroke(3, Color.WHITE) }
            elevation = 12f
        }
        bubbleParams = params().apply { width = dp(54); height = dp(54); gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(220) }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var dragged = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=bubbleParams.x; startY=bubbleParams.y; dragged=false; true }
                MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-downX).toInt(); val dy=(e.rawY-downY).toInt(); if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) dragged=true; bubbleParams.x=startX+dx; bubbleParams.y=startY+dy; wm.updateViewLayout(b,bubbleParams); true }
                MotionEvent.ACTION_UP -> { if (!dragged) togglePanel(); true }
                else -> false
            }
        }
        bubble = b
        wm.addView(b, bubbleParams)
    }

    private fun togglePanel() { if (panel == null) showPanel() else hidePanel() }

    private fun showPanel() {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply { setColor(Color.rgb(28, 30, 42)); cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.DKGRAY) }
            elevation = 18f
        }
        card.addView(TextView(this).apply { text="TẤT CẢ PHÍM TẮT  ·  NHATMINH"; setTextColor(Color.WHITE); textSize=15f; setPadding(0,0,0,dp(10)) })
        val rows = listOf(
            listOf("Mở Azota", "Ghi chú"),
            listOf("Đồng hồ", "Ẩn bảng"),
            listOf("Tắt công cụ", "Đóng")
        )
        rows.forEach { row ->
            val line = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            row.forEach { label ->
                val btn = Button(this).apply {
                    text = label
                    textSize = 12f
                    setTextColor(Color.WHITE)
                    setBackgroundTintList(android.content.res.ColorStateList.valueOf(when(label) { "Mở Azota" -> Color.rgb(28,120,220); "Ghi chú" -> Color.rgb(110,80,180); "Đồng hồ" -> Color.rgb(15,145,130); else -> Color.rgb(70,75,90) }))
                    layoutParams = LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
                    setOnClickListener { onTool(label) }
                }
                line.addView(btn)
            }
            card.addView(line)
        }
        val p = params().apply { gravity=Gravity.TOP or Gravity.END; x=dp(12); y=dp(150) }
        panel = card
        wm.addView(card,p)
    }

    private fun onTool(label: String) {
        when(label) {
            "Mở Azota" -> { val i=Intent(Intent.ACTION_VIEW, Uri.parse("https://azota.vn")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }
            "Ghi chú" -> Toast.makeText(this,"Bạn có thể dùng ứng dụng Ghi chú trên điện thoại.",Toast.LENGTH_LONG).show()
            "Đồng hồ" -> { val i=Intent("android.intent.action.SHOW_TIMERS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { startActivity(i) } catch (_: Exception) { Toast.makeText(this,"Hãy mở ứng dụng Đồng hồ.",Toast.LENGTH_SHORT).show() } }
            "Ẩn bảng", "Đóng" -> hidePanel()
            "Tắt công cụ" -> stopSelf()
        }
    }

    private fun hidePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel=null }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onDestroy() { hidePanel(); bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
