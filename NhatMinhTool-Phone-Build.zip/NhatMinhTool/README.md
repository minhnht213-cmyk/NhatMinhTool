# NHATMINH TOOL (Android)

Dự án Android Studio mẫu tạo nút nổi kéo-thả và bảng tiện ích nổi. Có lối tắt mở Azota, Ghi chú, Đồng hồ, Ẩn bảng và Tắt công cụ.

## Biên dịch APK
1. Cài Android Studio bản ổn định trên máy tính.
2. Chọn **Open** và mở thư mục `NhatMinhTool`.
3. Chờ Gradle Sync hoàn tất.
4. Chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

## Cài trên Android
- Chuyển APK sang điện thoại và cho phép cài ứng dụng từ nguồn bạn chọn.
- Mở NHATMINH TOOL, cấp quyền **Hiển thị trên ứng dụng khác**.
- Nhấn **Bật nút công cụ nổi**. Nút NM có thể kéo thả; chạm để mở bảng.

Đây là bản tiện ích thao tác nhanh, không tự đọc nội dung bài thi, không tự chọn đáp án và không tự nộp bài.
